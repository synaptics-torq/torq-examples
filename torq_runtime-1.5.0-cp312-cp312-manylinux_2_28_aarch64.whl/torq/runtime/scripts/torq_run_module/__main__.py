# Copyright 2025 Synaptics Inc.
#
# Licensed under the Apache License v2.0 with LLVM Exceptions.
# See https://llvm.org/LICENSE.txt for license information.
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception

import os
import subprocess
import sys

from torq._runtime_libs import library_path


def main(args=None):
    if args is None:
        args = sys.argv[1:]
    exe = os.path.join(library_path, "torq-run-module")
    return subprocess.call(args=[exe] + args)


if __name__ == "__main__":
    sys.exit(main())
